-- MySQL dump 10.13  Distrib 5.6.45, for Linux (x86_64)
--
-- Host: rdbms.strato.de    Database: DB4396391
-- ------------------------------------------------------
-- Server version	5.6.42-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `contents` text NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logofooter` varchar(255) DEFAULT NULL,
  `mission` text NOT NULL,
  `vision` text NOT NULL,
  `values2` text NOT NULL,
  `bank` varchar(255) NOT NULL,
  `iban` varchar(255) NOT NULL,
  `about_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` VALUES (1,'HumaneR','<p><strong>OUR VALUES </strong></p>\r\n\r\n<p><strong>Integrity</strong></p>\r\n\r\n<p>It&rsquo;s the backbone of HumaneR philosophy.&nbsp;Good intent drives great impact, and we strive to lead by example and ensure our decisions and choices make an impact as enlisted in our non- profit code of ethics</p>\r\n\r\n<p><strong>Empowerment</strong></p>\r\n\r\n<p>We strive to work hard and fix larger systemic problems and empower refugees across Europe live a better life. This is clearly depicted in the character of HumaneR wherein the organization is run by the refugees and is for the refugees.</p>\r\n\r\n<p><strong>Excellence</strong></p>\r\n\r\n<p>Refugees are people and people are human asset. HumaneR intends to open doors for these refugees across Europe to give their lives a substantial meaning and direction. Our passion to achieve this objective is a journey not a destination.We are constantly evaluating, training ourselves and setting new benchmarks to routinely succeed.</p>\r\n\r\n<p><strong>Embracing Community</strong></p>\r\n\r\n<p>We believe that we cannot walk alone if we want to walk a long distance. Keeping this thought deep in the character of HumaneRwe have joined hands with businesses, and government. We aim to bridge the societal gaps for the refugees and provide equal opportunity experience to them in all fields. This is a direct reflection of our community engagement wherein we are using the existing knowledge and resources to build this talent organization.</p>\r\n\r\n<p><strong>Curiosity</strong></p>\r\n\r\n<p>It&rsquo;s been the reason of our being and we ensure we never settle down until we explore all possibilities to create new models of inclusivity and financial independence that are sustainable and replicable.</p>\r\n','logofooter.png','logofooter.png','HumaneR is dedicated to help refugees across Europe in building a sustainable future for them. We work to bring quality impact in their lives by training them on skill gaps and preparing them for jobs and entrepreneurship.   We pursue this mission with empathy, transparency and support from government and businesses.','Our vision for every refugee is a level playing field and a road to self-reliance.','Our values are integrity, empowerment, excellence, embracing community and curiosity.','','','261f6c82a099731.jpg');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `about_counter`
--

DROP TABLE IF EXISTS `about_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about_counter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `complete` int(3) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_counter`
--

LOCK TABLES `about_counter` WRITE;
/*!40000 ALTER TABLE `about_counter` DISABLE KEYS */;
INSERT INTO `about_counter` VALUES (1,8,'Projects'),(2,1,'Companies'),(3,15,'Donations'),(4,6,'Volunteers');
/*!40000 ALTER TABLE `about_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `text` text NOT NULL,
  `picture` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `publish_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'Refugee centres are full as more and more asylum seekers come to the Netherlands','<p>The number of refugees and their families coming to the Netherlands rose to 1,400 in the third quarter of the year. As reported in Dutchnews.nl there are a total of 5,900 asylum seekers came to the Netherlands between July and September, a rise of 700 on the previous quarter</p>\r\n\r\n<p>Biggest chunk are the people coming in to join their already existing family members. According to reports they account for around 1200 of the total.</p>\r\n\r\n<p>As per refugee resettlement agency COA, reception centres are now full and the number of people currently living in COA accommodation has reached nearly 27,000. The 2000 reserve places set aside for emergencies are also used as per the reports.</p>\r\n\r\n<p>Housing emerges as a challenge wherein 5,500 people with residency permits are living in centres when they should have moved on to a regular home.</p>\r\n','308c2f2e6365e6d..jpg',0,'2021-01-08 11:09:00'),(2,'Protecting refugees in Europe: UNHCR calls for a ‘year of change’','<p>The UN refugee agency (UNHCR) is calling on the European Union (EU) to make 2020 &ldquo;the year of change for robust refugee protection As per UN news ,UNHCR said that the ambitious but achievable recommendations would provide a common and workable asylum system within the EU through sustainable reform and revitalized financial support for host countries.&nbsp;</p>\r\n\r\n<p>The UNHCR released a document with major highlight on 2 aspect for protecting refugees and Europe and abroad namely, moving ahead with sustainable asylum reform: and providing more support for the countries taking in refugees.&nbsp;</p>\r\n\r\n<p>As per the agency &ldquo;fair and fast asylum procedures need to be established to quickly determine who needs international protection and who does not.&rdquo; UNHCR also recommends foe truly common and workable asylum system owing to the fact that EU member states receives disproportionate number of asylum claims</p>\r\n\r\n<p>Need of revitalized financial support is also highlighted by the agency as 85% of world refugees are hosted in neighbouring countries. UNHCR called on the presidencies to ensure increased and diversified funding, including for development cooperation funding, to further support host countries and help forcibly displaced people rebuild their lives.&nbsp;</p>\r\n','167efcf6187cf36..jpg',0,'2021-01-11 16:03:00');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_author`
--

DROP TABLE IF EXISTS `blog_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_author` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `isdeleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_author`
--

LOCK TABLES `blog_author` WRITE;
/*!40000 ALTER TABLE `blog_author` DISABLE KEYS */;
INSERT INTO `blog_author` VALUES (1,'Isa KOC','icerik yazar hakkinda','',0);
/*!40000 ALTER TABLE `blog_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_author` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `tags` varchar(1000) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,1,'Blog1','awards.jpg',0,'2020-12-24 02:26:56','cevre,IT,programming','blog 1 icerik sayfasi'),(2,1,'Blog2','awards.jpg',0,'2020-12-24 02:26:56','BT,Isa','blog 1 icerik sayfasi');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactinfo`
--

DROP TABLE IF EXISTS `contactinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `googlemaps` text,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactinfo`
--

LOCK TABLES `contactinfo` WRITE;
/*!40000 ALTER TABLE `contactinfo` DISABLE KEYS */;
INSERT INTO `contactinfo` VALUES (1,'info@humaner.org','+31 638 41 30 93','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d380516.36852605286!2d4.7346991440797215!3d52.09358040268886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c609c3db87e4bb%3A0xb3a175ceffbd0a9f!2sHollanda!5e0!3m2!1str!2sfi!4v1609085829729!5m2!1str!2sfi\" width=\"1400\" height=\"650\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','Amsterdam, Netherlands');
/*!40000 ALTER TABLE `contactinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donations`
--

DROP TABLE IF EXISTS `donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cause_id` int(11) DEFAULT NULL,
  `dname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `amount` float NOT NULL,
  `is_paid` int(11) DEFAULT '0',
  `is_deleted` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donations`
--

LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` VALUES (23,2,'FATIH MERIC KOC','ikoc4562@gmail.com',NULL,100,1,1);
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `googlemaps` text NOT NULL,
  `picture` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `address` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `adddate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Reaching Out to Refugees','<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d23408.64592324357!2d32.56993170394586!3d0.3186712001564331!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sZzimwe%20Road%20Plot%204345%20Muyenga%2C%20Kampala%20UGANDA!5e0!3m2!1str!2sfi!4v1603927844183!5m2!1str!2sfi\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','event1.jpg',1,'2017-03-17 22:57:21','Uganda','Nile Humanitarian Development Agency under its Food and Aid program has extended out to the Kampala Urban Refugees through Inter-Aid Uganda, Office of the Prime Minister – Uganda and United Nations high Commission for Refugees. The program involved distribution of Food and Sanitary items to 150 families, most of whom were Patients with Special Needs (PSNs).\r\n\r\n\r\n\r\nUganda is home to over 500,000 refugees and Asylum seekers from Burundi, South Sudan, Democratic Republic of Congo, Chad, Rwanda, Eritrea and many others. Close to 85,000 of the total refugee population live in central urban areas. A large percentage of these do not earn a living due to their background and challenges of fully integrating into the Ugandan Society. This makes it extremely hard for them to afford good accommodation, health, and food given the limited financial aid from support organizations and the government.\r\n\r\n\r\n\r\nIdentifying this gap, Nile Humanitarian Development Agency reached out to many refugees in the urban settlements of different races and ages with food items and sanitary items including cooking oil, Spaghetti, Sugar, Hand washing soap, wheat and many more.','2017-02-12'),(2,'Our Ramadan 2019 Campaign','<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d23408.64592324357!2d32.56993170394586!3d0.3186712001564331!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sZzimwe%20Road%20Plot%204345%20Muyenga%2C%20Kampala%20UGANDA!5e0!3m2!1str!2sfi!4v1603927844183!5m2!1str!2sfi\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','event2.jpg',1,'2019-04-12 13:34:21','Uganda','We invite you to participate in our Ramadan campaign to reach out to people who are in need. We distribute qurban meat on behalf of our donors to needy people in Uganda.\r\n\r\nThank you for all of your support.','2019-03-04'),(3,'Qurban 2019 Campaign','<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d23408.64592324357!2d32.56993170394586!3d0.3186712001564331!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sZzimwe%20Road%20Plot%204345%20Muyenga%2C%20Kampala%20UGANDA!5e0!3m2!1str!2sfi!4v1603927844183!5m2!1str!2sfi\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','event2.jpg',1,'2019-07-17 13:34:21','Uganda','We invite you to participate in our qurban campaign to reach out to people who are in need. We distribute qurban meat on behalf of our donors to needy people in Uganda.\r\n\r\nThank you for all of your support.','2019-06-04'),(4,'Holy Ramadan 2016','<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d23408.64592324357!2d32.56993170394586!3d0.3186712001564331!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sZzimwe%20Road%20Plot%204345%20Muyenga%2C%20Kampala%20UGANDA!5e0!3m2!1str!2sfi!4v1603927844183!5m2!1str!2sfi\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','event1.jpg',1,'2016-06-08 22:57:21','Uganda','In the holly Ramadhan 2 tents serving fast breaking meals to needy people in Uganda By Nile Humanitarian.. NILE HUMANITARIAN distrubuted food aid to needy people in Kibula Kampala UGANDA.','2016-06-01'),(5,'NBA Star Enes Kanter visited our agency','<iframe src=\"https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d23408.64592324357!2d32.56993170394586!3d0.3186712001564331!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sZzimwe%20Road%20Plot%204345%20Muyenga%2C%20Kampala%20UGANDA!5e0!3m2!1str!2sfi!4v1603927844183!5m2!1str!2sfi\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>','event1.jpg',1,'2016-06-26 12:57:21','Uganda','NBA Star Enes Kanter visited our agency. NBA star ENES KANTER contrubited food with Nile Humanitarian to who needy people.','2016-06-12'),(6,'1','dd','dsfsf',1,'2020-06-12 00:00:00','dfffdg','gfdgdfgg','2020-12-12'),(7,'Deneme sdsadadsdsaas','fdgfgfgd213232343','dee2b160bc3503b..jpg',1,'2020-10-16 04:29:00','sfdfdfsdfsd','<p>23444353453545</p>\r\n','2020-10-30');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kullanicilar`
--

DROP TABLE IF EXISTS `kullanicilar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kullanicilar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `sifre` varchar(255) DEFAULT NULL,
  `aktifmi` int(11) DEFAULT '0',
  `resim` varchar(255) DEFAULT NULL,
  `token` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kullanicilar`
--

LOCK TABLES `kullanicilar` WRITE;
/*!40000 ALTER TABLE `kullanicilar` DISABLE KEYS */;
INSERT INTO `kullanicilar` VALUES (2,'ikoc4562@gmail.com','4562',0,'242312fdda886a8.jpg','26ea016198c295e61600367dd31d3511ac30b7f244eb4112'),(3,'deniz.4826fi@gmail.com','deniz',0,'242312fdda886a8.jpg','60621250f7ebb2e04374191a0a8b9bfaeb6aab8d3464f795'),(4,'orhank.ozbakir@gmail.com','kerem',0,'242312fdda886a8.jpg','adf7aa7a73614a31dbc60a77a6a4922b4a77d9ecbb3a8d48'),(5,'info@humaner.org','4562',0,'ad067e6e846b383.png','4d453eda9ea7b07c7d69d311211a80e9f8288f5d94a82a9b');
/*!40000 ALTER TABLE `kullanicilar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesajlar`
--

DROP TABLE IF EXISTS `mesajlar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mesajlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isim` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mesaj` varchar(255) DEFAULT NULL,
  `okundumu` int(11) DEFAULT '0',
  `aktifmi` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesajlar`
--

LOCK TABLES `mesajlar` WRITE;
/*!40000 ALTER TABLE `mesajlar` DISABLE KEYS */;
INSERT INTO `mesajlar` VALUES (25,'ISA KOC','ikoc4562@gmail.com','+358406863072','deneme',1,0),(26,'FATIH MERIC KOC','ikoc4562@gmail.com','+358406863072','fwefewfrre',1,0),(27,'Test 1','asda@asd.com','asdasdas','asdasd',1,0),(28,'Joe Miller','info@domainworld.com','+12548593423','Notice#: 491343\r\nDate: 2021-01-02  \r\n\r\nYOUR IMMEDIATE ATTENTION TO THIS MESSAGE IS ABSOLUTELY NECESSARY!\r\n\r\nYOUR DOMAIN humaner.org WILL BE TERMINATED WITHIN 24 HOURS\r\n\r\nWe have not received your payment for the renewal of your domain humaner.org\r\n\r\nWe ha',0,0),(29,'Joe Miller','info@domainworld.com','+12548593423','Notice#: 491343\r\nDate: 2021-01-02  \r\n\r\nYOUR IMMEDIATE ATTENTION TO THIS MESSAGE IS ABSOLUTELY NECESSARY!\r\n\r\nYOUR DOMAIN humaner.org WILL BE TERMINATED WITHIN 24 HOURS\r\n\r\nWe have not received your payment for the renewal of your domain humaner.org\r\n\r\nWe ha',0,0),(30,'','','','',0,0),(31,'','','','asd asd',0,0),(32,'','','','asdasdasd',0,0),(33,'','','','',0,0),(34,'ISA KOC','ikoc4562@gmail.com','+358406863072','fdsdsfssdf',0,0),(35,'ISA KOC','ikoc4562@gmail.com','+358406863072','deneme',0,0),(36,'Yas','yasin@gmail.com','06','jgkjgkjgkjgkj',0,1),(37,'Yas','yasin@gmail.com','06','jgkjgkjgkjgkj',0,1),(38,'ssdsd','asdsaad@dd','333','sadasdasda',0,1);
/*!40000 ALTER TABLE `mesajlar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partners`
--

DROP TABLE IF EXISTS `partners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `isdeleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partners`
--

LOCK TABLES `partners` WRITE;
/*!40000 ALTER TABLE `partners` DISABLE KEYS */;
INSERT INTO `partners` VALUES (1,'Gemeente Amsterdam','https://www.amsterdam.nl/','e7795218f360c5f.png',0),(2,'SC','https://www.suomiconnect.fi/','d4acfb58761dcd3.png',1);
/*!40000 ALTER TABLE `partners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portfolio`
--

DROP TABLE IF EXISTS `portfolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `picture` varchar(255) NOT NULL,
  `group_type` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolio`
--

LOCK TABLES `portfolio` WRITE;
/*!40000 ALTER TABLE `portfolio` DISABLE KEYS */;
INSERT INTO `portfolio` VALUES (29,NULL,'family_5.jpg',NULL,1),(30,NULL,'Construction-Workers.jpg',NULL,1),(31,NULL,'104318935-P1020464.JPG',NULL,1),(32,NULL,'immigrant-farmworkers.jpg',NULL,1),(33,'','affection-children-dad-daddy-embrace-family-1551149-pxhere.com_.jpg','',1),(34,NULL,'Construction-Workers-min.jpg',NULL,1),(35,NULL,'family_photo_with_dog_alameda.jpg',NULL,1),(36,NULL,'greenhouse-workers.jpg',NULL,1),(37,NULL,'mechanic-with-checklist.jpg',NULL,1),(38,NULL,'immigrant-farmworkers.jpg',NULL,1);
/*!40000 ALTER TABLE `portfolio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'Marketing','Lorem ipsum dolor amet consectetur adipisicing elit sed eiusmod tempor incididunt labore dolor magna aliqua enim ad minimveniam quis nostrud exercitation laboris.','fa-cart-arrow-down',0),(2,'Health','Lorem ipsum dolor amet consectetur adipisicing elit sed eiusmod tempor incididunt labore dolor magna aliqua enim ad minimveniam quis nostrud exercitation laboris.','fa-plane',1),(3,'Funding','Lorem ipsum dolor amet consectetur adipisicing elit sed eiusmod tempor incididunt labore dolor magna aliqua enim ad minimveniam quis nostrud exercitation laboris.','fa-mobile-phone',1),(4,'Water','Lorem ipsum dolor amet consectetur adipisicing elit sed eiusmod tempor incididunt labore dolor magna aliqua enim ad minimveniam quis nostrud exercitation laboris.','fa-bolt',1),(5,'Entrepreneurship','Lorem ipsum dolor amet consectetur adipisicing elit sed eiusmod tempor incididunt labore dolor magna aliqua enim ad minimveniam quis nostrud exercitation laboris.','fa-building',0),(12,'Training','','fa-graduation-cap',0);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `text` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` VALUES (1,'HumaneR ','Founded in 2020, HumaneR specializes in creating a sustainable living for the refugees across Europe. ','ace3fa56eeff411.jpg',0),(2,'Clean water changes absolutely everthing.','We must wotk together.','93313c92bce0873.JPG',1),(3,'deneme','deneme','deenme',1),(4,'deeme','ddd','564174918c70bad.jpg',1),(5,'HumaneR','We are trusted by governments, Corporate, Businesses,Relief organizations and refugees alike. Our work enables the refugee community to protect their future and make it secure. ','d1f678eee945736.jpg',0),(6,'HumaneR','Our unique preposition that holds us as ONE is our endeavour to start HumaneR with the Refugees. They are the ones running it for themselves and to support others like them. It is “BY the refugees and FOR the refugees”. ','c35db253cc4141f.jpg',0),(7,'HumaneR','We train them to become entrepreneurs or work as freelancers or we help them find jobs. We are helping them set up small businesses and pave the path for self-reliance. Are you with us in it?','1c97840b3e8e402.jpg',0);
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_media`
--

DROP TABLE IF EXISTS `social_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_media`
--

LOCK TABLES `social_media` WRITE;
/*!40000 ALTER TABLE `social_media` DISABLE KEYS */;
INSERT INTO `social_media` VALUES (1,'https://www.facebook.com/humaner',0,'facebook'),(2,'https://twitter.com/humaner',0,'twitter'),(3,'https://www.pinterest.com/humaner',0,'pinterest'),(5,'instagram2',1,'Instagram2'),(6,'vimeo',1,'vimeo');
/*!40000 ALTER TABLE `social_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_volunteers`
--

DROP TABLE IF EXISTS `staff_volunteers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_volunteers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `isdeleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_volunteers`
--

LOCK TABLES `staff_volunteers` WRITE;
/*!40000 ALTER TABLE `staff_volunteers` DISABLE KEYS */;
INSERT INTO `staff_volunteers` VALUES (1,'Emre','13be2d916bbf8d9.jpg','','facebook.com',1),(2,'EMRE','0aa2130b106b327jpeg','Emre has a diversified experience for nearly 20 years in the field of Quality Management, Human Resources and recruitment processes. He is also a refined educator and ISO 9001-2015 Lead Auditor. He is a volunteer who spends his energy to benefit people. ','',0);
/*!40000 ALTER TABLE `staff_volunteers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stories`
--

DROP TABLE IF EXISTS `stories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `text` varchar(5000) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stories`
--

LOCK TABLES `stories` WRITE;
/*!40000 ALTER TABLE `stories` DISABLE KEYS */;
INSERT INTO `stories` VALUES (1,'C Nil','Success Story - 2','695816e650c5044.jpg',0),(2,'Diversity & Inclusion','Success Story - 1','4ac2ef51d1771fb.jpg',0),(3,'3','3','37226846c97cb71..JPG',1),(4,'Training of Refugees','Success Story - 3','20430071c8dec3b..jpg',0);
/*!40000 ALTER TABLE `stories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `explanation` text NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `linkedin` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL,
  `isdeleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,'André Le Cat','Board Member','f127173ea28b62cjpeg','<p>Andr&eacute; Le cat has been working in the banking sector for over 30 years mainly in the area of innovation. He has been an entrepreneur for several years setting up new businesses.</p>\r\n\r\n<p>Andr&eacute; has co-authored a book in Dutch on knowledge-based working that was published in 2009. He now puts his social hat and is working hand in hand with HumaneR to help the organization achieve its goals.</p>\r\n','','','https://www.linkedin.com/in/andrelecat/','',0),(2,'Rob Jansen','Board Member','06ba6b0864b09d8jpeg','<p>Rob is a social entrepreneur with over twenty years of diverse experience in sales, marketing and entrepreneurship. He has a fire within to collaborate, and make things happen.&nbsp;He is deeply influenced by the plight of the refugees and decided to take a plunge to work with them in order to create a sustainable future for them. He feels, &quot;life without a cause is not worth living.&quot;</p>\r\n\r\n<p>To achieve his mission, he has surrounded himself by some very experienced, talented team and together they have set out to build a social enterprise that can bring an impact. Bringing like-minded people together who can live the organization&#39;s vision and values, HumaneR is now a voice for the refugees.&nbsp;</p>\r\n','','','https://www.linkedin.com/in/robjansen69/','',0),(3,'Jagdeep','','92aa8be3c2cb979..jpg','','','','','',1),(4,'Staff yeni','Ceo','88767fdd1d8206a..jpg','<p>Staff info</p>\r\n','','','','',1);
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `link` varchar(1000) NOT NULL,
  `text` text NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (1,'Cataract Campaign - Uganda\r\n','https://www.youtube.com/watch?v=5HA7A9JApqE&ab_channel=StichtingTimeToHelpNederland','Cataract operations are being conducted in a hospital in Jinja city in Uganda as part of our cataract campaign, conducted in collaboration with Nile Humanitarian Agency Development.','download.jpeg',1);
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-14 17:21:59
